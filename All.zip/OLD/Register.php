<?php
 ob_start();
 session_start();
 
 include_once 'dbconnect.php';

 $error = false;

 if ($_SERVER["REQUEST_METHOD"]=="POST" ) {
  
  // clean user inputs to prevent sql injections
  $username = trim($_POST['Username']);
  $username = strip_tags($username);
  $username = htmlspecialchars($username);
  
  $email = trim($_POST['Email']);
  $email = strip_tags($email);
  $email = htmlspecialchars($email);
  
  $password = trim($_POST['Password']);
  $password = strip_tags($password);
  $password = htmlspecialchars($password);

  $area = trim($_POST['Area']);
  $area = strip_tags($area);
  $area = htmlspecialchars($area);

  $phone = trim($_POST['Phone']);
  $phone = strip_tags($phone);
  $phone = htmlspecialchars($phone);

  $city = trim($_POST['City']);
  $city = strip_tags($city);
  $city = htmlspecialchars($city);

  $state = trim($_POST['State']);
  $state = strip_tags($state);
  $state = htmlspecialchars($state);

  $name = trim($_POST['Name']);
  $name = strip_tags($name);
  $name = htmlspecialchars($name);

  $occupation = trim($_POST['Occupation']);
  $occupation = strip_tags($occupation);
  $occupation = htmlspecialchars($occupation);

  $income = trim($_POST['Income']);
  $income = strip_tags($income);
  $income = htmlspecialchars($income);
  $image="";
  /*
    $target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $image = $_FILES['image']['tmp_name'];
        $imgContent = addslashes(file_get_contents($image));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}*/
$pass=$password;
  // basic name validation
  $error=false;
  if (empty($name)) {
   $error = true;
   $nameError = "Please enter your full name.";
  } else if (strlen($name) < 3) {
   $error = true;
   $nameError = "Name must have atleat 3 characters.";
  } else if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
   $error = true;
   $nameError = "Name must contain alphabets and space.";
  }
  //basic email validation
  if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
   $error = true;
   $emailError = "Please enter valid email address.";
  } else {
   // check email exist or not
   $query = "SELECT Username FROM Users WHERE Username='$Username'";
   $result = mysqli_query($conn,$query);
   $count = mysqli_num_rows($result);
   if($count!=0){
    $error = true;
    $emailError = "Provided Username is already in use.";
   }
  }
  // password validation
  if (empty($pass)){
   $error = true;
   $passError = "Please enter password.";
  } else if(strlen($pass) < 6) {
   $error = true;
   $passError = "Password must have atleast 6 characters.";
  }
  
  // password encrypt using SHA256();
  $password = hash('sha256', $pass);
  
  // if there's no error, continue to signup
  echo mysqli_error($conn);
echo $error;
echo $nameError;
echo $emailError;
echo $passError;
  if( !$error ) {
   echo "HERE";
   echo $username;
   $query = "INSERT INTO Users(Username,Password,Name, Email, Phone,Area, City, State, Occupation, Income, image) VALUES('$username','$password','$name','$email','$phone','$area','$city','$state','$occupation','$income','$image')";
   $res = mysqli_query($conn,$query);
   echo mysqli_error($conn);
   $query1 = "create table '$Username' (Farm_id INT(6) UNSIGNED AUTO_INCREMENT, time timestamp, Temperature double(2,2), Humidity double(2,2), CO2 double(2,2), Amount int(10 )";
    
   if ($res) {
    $errTyp = "success";
    $errMSG = "Successfully registered, you may login now";
    unset($Name);
    unset($Email);
    unset($Password);
    unset($Income);
    unset($Occupation);
    unset($State);
    unset($City);
    unset($Username);
    unset($Area);
    unset($Phone);
   } else {
    $errTyp = "danger";
    $errMSG = "Something went wrong, try again later..."; 
   } 
    
  }
  
 
 }
 