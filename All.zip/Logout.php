<?php
if (isset($_SESSION['loggedIn')) {
$tmp = $_SESSION['Username'];
session_destroy();
session_regenerate_id();
$_SESSION['Username'] = $tmp;
}
?>